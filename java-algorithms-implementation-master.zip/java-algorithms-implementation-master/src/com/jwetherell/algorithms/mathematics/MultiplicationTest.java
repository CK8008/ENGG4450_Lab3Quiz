package com.jwetherell.algorithms.mathematics;

import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;
//*NOTE* I am only doing 5 methods as multiply has a lot.

public class MultiplicationTest {
    @Test
    public void multiplication() {
        assertEquals(80, Multiplication.multiplication(40,2));
        assertEquals(-80, Multiplication.multiplication(-40,2));
        assertEquals(-80, Multiplication.multiplication(40,-2));
        assertEquals(80, Multiplication.multiplication(-40,-2));
        assertEquals(0, Multiplication.multiplication(0,2));
        assertEquals(0, Multiplication.multiplication(2,0));
    }

    @Test
    public void multiplyUsingLoops(){
        assertEquals(80, Multiplication.multiplyUsingLoop(40,2));
        assertEquals(-80, Multiplication.multiplyUsingLoop(-40,2));
        assertEquals(-80, Multiplication.multiplyUsingLoop(40,-2));
        assertEquals(80, Multiplication.multiplyUsingLoop(-40,-2));
        assertEquals(0, Multiplication.multiplyUsingLoop(0,2));
        assertEquals(0, Multiplication.multiplyUsingLoop(2,0));
    }

    @Test
    public void multiplyUsingRecurion(){
        assertEquals(80, Multiplication.multiplyUsingRecursion(40,2));
        assertEquals(-80, Multiplication.multiplyUsingRecursion(-40,2));
        assertEquals(-80, Multiplication.multiplyUsingRecursion(40,-2));
        assertEquals(80, Multiplication.multiplyUsingRecursion(-40,-2));
        assertEquals(0, Multiplication.multiplyUsingRecursion(0,2));
        assertEquals(0, Multiplication.multiplyUsingRecursion(2,0));
    }

    @Test
    public void multiplyUsingShift(){
        assertEquals(80, Multiplication.multiplyUsingShift(40,2));
        assertEquals(-80, Multiplication.multiplyUsingShift(-40,2));
        assertEquals(-80, Multiplication.multiplyUsingShift(40,-2));
        assertEquals(80, Multiplication.multiplyUsingShift(-40,-2));
        assertEquals(0, Multiplication.multiplyUsingShift(0,2));
        assertEquals(0, Multiplication.multiplyUsingShift(2,0));
    }

    @Test
    public void multiplyUsingLogs(){
        assertEquals(80, Multiplication.multiplyUsingLogs(40,2));
        assertEquals(-80, Multiplication.multiplyUsingLogs(-40,2));
        assertEquals(-80, Multiplication.multiplyUsingLogs(40,-2));
        assertEquals(80, Multiplication.multiplyUsingLogs(-40,-2));
        assertEquals(0, Multiplication.multiplyUsingLogs(0,2));
        assertEquals(0, Multiplication.multiplyUsingLogs(2,0));
    }

}