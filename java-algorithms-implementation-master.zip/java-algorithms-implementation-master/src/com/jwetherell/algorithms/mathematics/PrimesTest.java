package com.jwetherell.algorithms.mathematics;

import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PrimesTest {
    @Test
    public void getPrimeFactorization() {

        //assertTrue(Primes.getPrimeFactorization(5));
        //assertFalse(Primes.getPrimeFactorization(4));
    }

    @Test
    public void isPrime() {

        assertTrue(Primes.isPrime(5));
        assertFalse(Primes.isPrime(4));
    }

    @Test
    public void sieveOfEratosthenes() {

        assertTrue(Primes.sieveOfEratosthenes(5));
        assertFalse(Primes.sieveOfEratosthenes(4));

    }

    @Test
    public void millerRabinTest(){

        assertTrue(Primes.millerRabinTest(5));
        assertFalse(Primes.millerRabinTest(4));
    }
}